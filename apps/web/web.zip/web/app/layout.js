import "./globals.css";
import Header from "../components/Header";
import TopNav from "../components/TopNav";
import ToasterClient from "../components/ToasterClient";

export default function RootLayout({ children }) {
  return (
    <html lang="bg">
      <body>
        <div className="min-h-screen">
          <ToasterClient />
          <Header />
          <TopNav />
          <main className="mx-auto max-w-6xl px-4 py-6">{children}</main>
        </div>
      </body>
    </html>
  );
}
