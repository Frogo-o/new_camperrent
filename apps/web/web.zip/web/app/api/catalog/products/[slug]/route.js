import { NextResponse } from "next/server";

const API_BASE_URL = process.env.API_BASE_URL || "http://localhost:4000";

export async function GET(_req, { params }) {
    try {
        const { slug } = await params;

        if (!slug) {
            return NextResponse.json({ message: "Missing slug" }, { status: 400 });
        }

        const safe = encodeURIComponent(slug);
        const target = `${API_BASE_URL}/api/catalog/products/${safe}`;

        const res = await fetch(target, { cache: "no-store" });
        const body = await res.text();

        return new NextResponse(body, {
            status: res.status,
            headers: {
                "content-type": res.headers.get("content-type") || "application/json; charset=utf-8",
            },
        });
    } catch (e) {
        return NextResponse.json(
            { message: "Proxy error", details: String(e?.message || e) },
            { status: 502 }
        );
    }
}