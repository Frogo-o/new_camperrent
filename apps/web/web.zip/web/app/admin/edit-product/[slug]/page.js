"use client";

import { useEffect, useMemo, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import toast from "react-hot-toast";

function centsToEurString(cents) {
    const n = Number(cents);
    if (!Number.isFinite(n)) return "";
    return (n / 100).toFixed(2);
}

function eurToCents(v) {
    const x = String(v || "").replace(",", ".").trim();
    const n = Number(x);
    if (!Number.isFinite(n)) return NaN;
    return Math.round(n * 100);
}

function slugify(v) {
    return String(v || "")
        .trim()
        .toLowerCase()
        .replace(/\s+/g, "-")
        .replace(/[^a-z0-9\-]/g, "")
        .replace(/\-+/g, "-")
        .replace(/^\-+|\-+$/g, "");
}

function ensureCamperCategoriesAtEnd(list) {
    const arr = Array.isArray(list) ? list.slice() : [];
    const bySlug = new Set(arr.map((x) => String(x?.slug || "").trim()).filter(Boolean));

    const extras = [
        { id: 3, name: "Наем-Кемпер", slug: "camper-rent" },
        { id: 4, name: "Купи-Кемпер", slug: "buy-camper" },
    ];

    for (const c of extras) {
        if (!bySlug.has(c.slug)) arr.push(c);
    }

    return arr;
}

export default function EditProductClient() {
    const params = useParams();
    const router = useRouter();
    const currentSlug = useMemo(() => String(params.slug || ""), [params.slug]);

    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    const [categories, setCategories] = useState([]);
    const [brands, setBrands] = useState([]);

    const [name, setName] = useState("");
    const [slug, setSlug] = useState("");
    const [description, setDescription] = useState("");
    const [priceEur, setPriceEur] = useState("");
    const [categoryId, setCategoryId] = useState("");
    const [brandId, setBrandId] = useState("");
    const [isActive, setIsActive] = useState(true);

    useEffect(() => {
        let alive = true;

        async function loadMeta() {
            try {
                const [cRes, bRes] = await Promise.all([
                    fetch("/api/catalog/categories", { cache: "no-store" }),
                    fetch("/api/catalog/brands", { cache: "no-store" }),
                ]);

                const cJson = await cRes.json().catch(() => null);
                const bJson = await bRes.json().catch(() => null);

                if (!alive) return;

                const c = ensureCamperCategoriesAtEnd(cJson?.data || []);
                const b = Array.isArray(bJson?.data) ? bJson.data : [];

                setCategories(c);
                setBrands(b);
            } catch {
                if (!alive) return;
                toast.error("Не успях да заредя категории/брандове");
            }
        }

        loadMeta();
        return () => {
            alive = false;
        };
    }, []);

    useEffect(() => {
        let alive = true;

        async function loadProduct() {
            setLoading(true);
            try {
                const res = await fetch(`/api/admin/product-editor/${encodeURIComponent(currentSlug)}`, {
                    cache: "no-store",
                });

                const json = await res.json().catch(() => null);

                if (!res.ok) throw new Error(json?.message || "Грешка при зареждане на продукта");

                if (!alive) return;

                setName(String(json?.name || ""));
                setSlug(String(json?.slug || ""));
                setDescription(String(json?.description || ""));
                setPriceEur(centsToEurString(json?.price));
                setIsActive(Boolean(json?.isActive));
                setCategoryId(json?.categoryId ? String(json.categoryId) : "");
                setBrandId(json?.brandId ? String(json.brandId) : "");
            } catch (e) {
                if (!alive) return;
                toast.error(e?.message || "Грешка при зареждане");
            } finally {
                if (!alive) return;
                setLoading(false);
            }
        }

        if (currentSlug) loadProduct();

        return () => {
            alive = false;
        };
    }, [currentSlug]);

    async function saveProduct() {
        if (!name.trim()) return toast.error("Името е задължително");
        if (!slug.trim()) return toast.error("Slug е задължителен");
        if (!categoryId) return toast.error("Избери категория");

        const priceCents = eurToCents(priceEur);
        if (!Number.isInteger(priceCents) || priceCents < 0) return toast.error("Невалидна цена");

        setSaving(true);
        try {
            const payload = {
                name: name.trim(),
                slug: slug.trim(),
                description: description.trim(),
                price: priceCents,
                isActive,
                categoryId: Number(categoryId),
                brandId: brandId ? Number(brandId) : null,
            };

            const res = await fetch(`/api/admin/product-editor/${encodeURIComponent(currentSlug)}`, {
                method: "PATCH",
                headers: { "content-type": "application/json; charset=utf-8" },
                body: JSON.stringify(payload),
                cache: "no-store",
            });

            const json = await res.json().catch(() => null);

            if (!res.ok) throw new Error(json?.message || "Грешка при запазване");

            toast.success("Запазено");

            const newSlug = String(json?.slug || "");
            if (newSlug && newSlug !== currentSlug) {
                router.replace(`/admin/edit-product/${newSlug}`);
            }
        } catch (e) {
            toast.error(e?.message || "Грешка");
        } finally {
            setSaving(false);
        }
    }

    const disabled = loading || saving;

    return (
        <div className="mx-auto max-w-4xl p-6">
            <div className="mb-5">
                <h1 className="text-2xl font-bold text-slate-900">Редактирай продукт</h1>
                <div className="mt-1 text-sm text-slate-600">
                    Зареждане по slug → редакция → запазване
                </div>
            </div>

            <div className="grid gap-6 rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
                <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="text-sm text-slate-600">
                        Текущ slug: <span className="font-semibold text-slate-900">{currentSlug}</span>
                    </div>

                    <div className="flex items-center gap-2">
                        <button
                            type="button"
                            onClick={() => router.back()}
                            className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-900 shadow-sm transition hover:bg-slate-50"
                            disabled={disabled}
                        >
                            Назад
                        </button>

                        <button
                            type="button"
                            onClick={() => router.refresh()}
                            className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-900 shadow-sm transition hover:bg-slate-50"
                            disabled={disabled}
                        >
                            Refresh
                        </button>
                    </div>
                </div>

                {loading ? (
                    <div className="rounded-lg border border-dashed border-slate-200 p-4 text-sm text-slate-600">
                        Зареждане...
                    </div>
                ) : (
                    <>
                        <div className="grid gap-4 sm:grid-cols-2">
                            <div>
                                <label className="mb-1 block text-xs text-slate-600">Име</label>
                                <input
                                    value={name}
                                    onChange={(e) => {
                                        const v = e.target.value;
                                        setName(v);
                                        if (!slug.trim()) setSlug(slugify(v));
                                    }}
                                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-slate-900 shadow-sm outline-none transition focus:border-slate-300 focus:ring-4 focus:ring-slate-100"
                                    disabled={disabled}
                                />
                            </div>

                            <div>
                                <label className="mb-1 block text-xs text-slate-600">Slug</label>
                                <input
                                    value={slug}
                                    onChange={(e) => setSlug(slugify(e.target.value))}
                                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-slate-900 shadow-sm outline-none transition focus:border-slate-300 focus:ring-4 focus:ring-slate-100"
                                    disabled={disabled}
                                />
                            </div>

                            <div>
                                <label className="mb-1 block text-xs text-slate-600">Цена (EUR)</label>
                                <input
                                    value={priceEur}
                                    onChange={(e) => setPriceEur(e.target.value)}
                                    inputMode="decimal"
                                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-slate-900 shadow-sm outline-none transition focus:border-slate-300 focus:ring-4 focus:ring-slate-100"
                                    disabled={disabled}
                                />
                                <div className="mt-1 text-[11px] text-slate-500">
                                    Ще се запише като cents в бекенда.
                                </div>
                            </div>

                            <div>
                                <label className="mb-1 block text-xs text-slate-600">Категория</label>
                                <select
                                    value={categoryId}
                                    onChange={(e) => setCategoryId(e.target.value)}
                                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-slate-900 shadow-sm outline-none transition focus:border-slate-300 focus:ring-4 focus:ring-slate-100"
                                    disabled={disabled}
                                >
                                    {!categoryId ? <option value="">— избери —</option> : null}
                                    {categories.map((c) => (
                                        <option key={c.id} value={String(c.id)}>
                                            {c.name}
                                        </option>
                                    ))}
                                </select>
                            </div>

                            <div>
                                <label className="mb-1 block text-xs text-slate-600">Бранд (optional)</label>
                                <select
                                    value={brandId}
                                    onChange={(e) => setBrandId(e.target.value)}
                                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-slate-900 shadow-sm outline-none transition focus:border-slate-300 focus:ring-4 focus:ring-slate-100"
                                    disabled={disabled}
                                >
                                    <option value="">— без бранд —</option>
                                    {brands.map((b) => (
                                        <option key={b.id} value={String(b.id)}>
                                            {b.name}
                                        </option>
                                    ))}
                                </select>
                            </div>

                            <div className="flex items-end">
                                <label className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 shadow-sm">
                                    <input
                                        type="checkbox"
                                        checked={isActive}
                                        onChange={(e) => setIsActive(e.target.checked)}
                                        className="h-4 w-4"
                                        disabled={disabled}
                                    />
                                    Активен
                                </label>
                            </div>
                        </div>

                        <div>
                            <label className="mb-1 block text-xs text-slate-600">Описание</label>
                            <textarea
                                value={description}
                                onChange={(e) => setDescription(e.target.value)}
                                rows={4}
                                className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-slate-900 shadow-sm outline-none transition focus:border-slate-300 focus:ring-4 focus:ring-slate-100"
                                disabled={disabled}
                            />
                        </div>

                        <div className="flex justify-end">
                            <button
                                type="button"
                                onClick={saveProduct}
                                disabled={disabled}
                                className={[
                                    "rounded-lg px-4 py-2 text-sm font-semibold text-white shadow-sm transition",
                                    disabled ? "bg-slate-400" : "bg-sky-600 hover:bg-sky-700",
                                ].join(" ")}
                            >
                                {saving ? "Запазване..." : "Запази промените"}
                            </button>
                        </div>
                    </>
                )}
            </div>
        </div>
    );
}
