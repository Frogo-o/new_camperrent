import Link from "next/link";
import { notFound } from "next/navigation";
import AddToCartButton from "../../../components/AddToCartButton";
import ProductGallery from "../../../components/ProductGallery";
import OrderNowButton from "../../../components/OrderNowButton";

function formatEUR(cents) {
    const eur = Number(cents || 0) / 100;
    return new Intl.NumberFormat("bg-BG", {
        style: "currency",
        currency: "EUR",
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    }).format(eur);
}

export default async function ProductPage({ params }) {
    const { slug } = await params;

    if (!slug) notFound();

    const res = await fetch(
        `http://localhost:3000/api/catalog/products/${encodeURIComponent(slug)}`,
        { cache: "no-store" }
    );

    if (res.status === 404) notFound();

    const json = await res.json().catch(() => null);
    const p = json?.data || null;

    if (!p) notFound();

    const images = Array.isArray(p?.images) ? p.images : [];
    const firstImg = images?.[0]?.url || "";

    const categorySlug = p?.category?.slug || "";
    const categoryName = p?.category?.name || "";

    const isRent = categorySlug === "camper-rent" || categoryName === "Наем-Кемпер";
    const isBuyCamper = categorySlug === "buy-camper" || categoryName === "Купи-Кемпер";

    const shouldShowOrderForm = isRent || isBuyCamper;

    return (
        <div className="mx-auto max-w-5xl p-6">
            <div className="mb-4 text-sm text-slate-600">
                <Link className="hover:underline" href="/">
                    Начало
                </Link>
                <span className="mx-2">/</span>
                <span className="text-slate-900">{p.name}</span>
            </div>

            <div className="grid gap-6 lg:grid-cols-[1.3fr_1fr]">
                <ProductGallery images={images} name={p.name} />

                <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
                    <h1 className="text-2xl font-bold text-slate-900">{p.name}</h1>

                    <div className="mt-2 flex flex-wrap gap-2 text-sm text-slate-600">
                        <span>{p.category?.name}</span>
                        <span>•</span>
                        <span>{p.brand?.name || "Без марка"}</span>
                    </div>

                    <div className="mt-4 text-2xl font-extrabold text-slate-900">{formatEUR(p.price)}</div>

                    {shouldShowOrderForm ? (
                        <OrderNowButton
                            mode={isRent ? "rent" : "buy"}
                            product={{ id: p.id, name: p.name }}
                        />
                    ) : (
                        <AddToCartButton
                            product={{
                                id: p.id,
                                slug: p.slug,
                                name: p.name,
                                price: p.price,
                                imageUrl: firstImg,
                                categorySlug: p?.category?.slug || "",
                                categoryName: p?.category?.name || "",
                                brandName: p?.brand?.name || "",
                            }}
                            label="Добави в количка"
                        />
                    )}

                    {p.description ? (
                        <div className="mt-6">
                            <div className="text-sm font-semibold text-slate-900">Кратко описание</div>
                            <p className="mt-2 whitespace-pre-line text-sm text-slate-700">{p.description}</p>
                        </div>
                    ) : null}
                </div>
            </div>
        </div>
    );
}
