"use client";

import { useMemo, useState } from "react";
import toast from "react-hot-toast";

function cn(...xs) {
    return xs.filter(Boolean).join(" ");
}

function safeText(v) {
    return String(v || "").trim();
}

export default function OrderNowButton({ product, mode }) {
    const isRent = mode === "rent";
    const title = isRent ? "Заявка за наем" : "Запитване за покупка";

    const [open, setOpen] = useState(false);
    const [successOpen, setSuccessOpen] = useState(false);
    const [sending, setSending] = useState(false);

    const [form, setForm] = useState({
        customerName: "",
        email: "",
        phone: "",
        address: "",
        deliveryMethod: "COURIER",
        note: "",
    });

    const canSubmit = useMemo(() => {
        const customerName = safeText(form.customerName);
        const email = safeText(form.email);
        const phone = safeText(form.phone);
        const address = safeText(form.address);

        if (!customerName || customerName.length < 2) return false;
        if (!email || !email.includes("@")) return false;
        if (!phone || phone.length < 6) return false;

        if (form.deliveryMethod === "COURIER" && (!address || address.length < 5)) return false;

        return true;
    }, [form]);

    async function submit() {
        if (sending) return;
        if (!canSubmit) {
            toast.error("Моля попълни коректно формата.");
            return;
        }

        setSending(true);
        try {
            const payload = {
                items: [{ productId: product.id, qty: 1 }],
                customerName: safeText(form.customerName),
                email: safeText(form.email),
                phone: safeText(form.phone),
                address: safeText(form.address),
                deliveryMethod: form.deliveryMethod,
                note: safeText(form.note),
            };

            const res = await fetch("/api/orders", {
                method: "POST",
                headers: { "content-type": "application/json" },
                body: JSON.stringify(payload),
            });

            const json = await res.json().catch(() => null);

            if (!res.ok) {
                const msg = json?.message || "Грешка при изпращане на заявката.";
                toast.error(msg);
                setSending(false);
                return;
            }

            setOpen(false);
            setSuccessOpen(true);
            setSending(false);

            setForm({
                customerName: "",
                email: "",
                phone: "",
                address: "",
                deliveryMethod: "COURIER",
                note: "",
            });
        } catch {
            toast.error("Мрежова грешка. Опитай пак.");
            setSending(false);
        }
    }

    return (
        <>
            <button
                type="button"
                onClick={() => setOpen(true)}
                className={cn(
                    "mt-4 w-full rounded-lg px-4 py-2 text-sm font-semibold text-white shadow-sm transition",
                    isRent ? "bg-emerald-600 hover:bg-emerald-700" : "bg-indigo-600 hover:bg-indigo-700"
                )}
            >
                {isRent ? "Наеми този кемпер" : "Купи кемпер"}
            </button>

            {open ? (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                    <button
                        type="button"
                        onClick={() => (!sending ? setOpen(false) : null)}
                        className="absolute inset-0 bg-black/40"
                        aria-label="Close"
                    />

                    <div className="relative w-full max-w-xl overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xl">
                        <div className="flex items-start justify-between gap-4 border-b border-slate-200 p-5">
                            <div>
                                <div className="text-lg font-bold text-slate-900">{title}</div>
                                <div className="mt-1 text-sm text-slate-600">
                                    {product.name}
                                </div>
                            </div>

                            <button
                                type="button"
                                disabled={sending}
                                onClick={() => setOpen(false)}
                                className={cn(
                                    "rounded-lg border px-3 py-1.5 text-sm shadow-sm transition",
                                    sending
                                        ? "border-slate-200 bg-slate-50 text-slate-400"
                                        : "border-slate-200 bg-white text-slate-900 hover:bg-slate-50"
                                )}
                            >
                                Затвори
                            </button>
                        </div>

                        <div className="grid gap-4 p-5">
                            <div className="grid gap-3 sm:grid-cols-2">
                                <div>
                                    <label className="mb-1 block text-xs text-slate-600">Име и фамилия</label>
                                    <input
                                        value={form.customerName}
                                        onChange={(e) => setForm((s) => ({ ...s, customerName: e.target.value }))}
                                        className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-slate-900 shadow-sm outline-none transition focus:border-slate-300 focus:ring-4 focus:ring-slate-100"
                                        placeholder="Напр. Георги Ралчев"
                                    />
                                </div>

                                <div>
                                    <label className="mb-1 block text-xs text-slate-600">Телефон</label>
                                    <input
                                        value={form.phone}
                                        onChange={(e) => setForm((s) => ({ ...s, phone: e.target.value }))}
                                        className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-slate-900 shadow-sm outline-none transition focus:border-slate-300 focus:ring-4 focus:ring-slate-100"
                                        placeholder="0888123456"
                                    />
                                </div>

                                <div className="sm:col-span-2">
                                    <label className="mb-1 block text-xs text-slate-600">Имейл</label>
                                    <input
                                        value={form.email}
                                        onChange={(e) => setForm((s) => ({ ...s, email: e.target.value }))}
                                        className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-slate-900 shadow-sm outline-none transition focus:border-slate-300 focus:ring-4 focus:ring-slate-100"
                                        placeholder="name@email.com"
                                    />
                                </div>
                            </div>

                            <div className="grid gap-3 sm:grid-cols-2 sm:items-end">
                                <div>
                                    <label className="mb-1 block text-xs text-slate-600">Метод на доставка</label>
                                    <select
                                        value={form.deliveryMethod}
                                        onChange={(e) => setForm((s) => ({ ...s, deliveryMethod: e.target.value }))}
                                        className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-slate-900 shadow-sm outline-none transition focus:border-slate-300 focus:ring-4 focus:ring-slate-100"
                                    >
                                        <option value="COURIER">Куриер</option>
                                        <option value="PICKUP">Вземане на място</option>
                                    </select>
                                </div>

                                <div>
                                    <label className="mb-1 block text-xs text-slate-600">Адрес</label>
                                    <input
                                        value={form.address}
                                        onChange={(e) => setForm((s) => ({ ...s, address: e.target.value }))}
                                        disabled={form.deliveryMethod !== "COURIER"}
                                        className={cn(
                                            "w-full rounded-lg border px-3 py-2 shadow-sm outline-none transition focus:ring-4",
                                            form.deliveryMethod !== "COURIER"
                                                ? "border-slate-200 bg-slate-50 text-slate-400"
                                                : "border-slate-200 bg-white text-slate-900 focus:border-slate-300 focus:ring-slate-100"
                                        )}
                                        placeholder="Sofia, bul. Vitosha 1"
                                    />
                                </div>
                            </div>

                            <div>
                                <label className="mb-1 block text-xs text-slate-600">Бележка</label>
                                <textarea
                                    value={form.note}
                                    onChange={(e) => setForm((s) => ({ ...s, note: e.target.value }))}
                                    rows={3}
                                    className="w-full resize-none rounded-lg border border-slate-200 bg-white px-3 py-2 text-slate-900 shadow-sm outline-none transition focus:border-slate-300 focus:ring-4 focus:ring-slate-100"
                                    placeholder="Напр. Оставете пред вратата"
                                />
                            </div>

                            <div className="flex flex-col-reverse gap-3 sm:flex-row sm:items-center sm:justify-between">
                                <div className="text-xs text-slate-500">
                                    С натискане на “Изпрати” заявката ще бъде изпратена към екипа.
                                </div>

                                <button
                                    type="button"
                                    onClick={submit}
                                    disabled={!canSubmit || sending}
                                    className={cn(
                                        "rounded-lg px-4 py-2 text-sm font-semibold text-white shadow-sm transition",
                                        !canSubmit || sending
                                            ? "bg-slate-300"
                                            : isRent
                                                ? "bg-emerald-600 hover:bg-emerald-700"
                                                : "bg-indigo-600 hover:bg-indigo-700"
                                    )}
                                >
                                    {sending ? "Изпращане..." : "Изпрати"}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            ) : null}

            {successOpen ? (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                    <button
                        type="button"
                        onClick={() => setSuccessOpen(false)}
                        className="absolute inset-0 bg-black/40"
                        aria-label="Close"
                    />

                    <div className="relative w-full max-w-lg overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xl">
                        <div className="border-b border-slate-200 p-5">
                            <div className="text-lg font-bold text-slate-900">Заявката е изпратена</div>
                            <div className="mt-1 text-sm text-slate-600">
                                Изпратихме потвърждение по имейл. Очаквайте обаждане до <span className="font-semibold">2 работни дни</span>.
                            </div>
                        </div>

                        <div className="p-5">
                            <div className="rounded-xl bg-slate-50 p-4 text-sm text-slate-700">
                                Продукт: <span className="font-semibold text-slate-900">{product.name}</span>
                            </div>

                            <button
                                type="button"
                                onClick={() => setSuccessOpen(false)}
                                className="mt-4 w-full rounded-lg bg-sky-600 px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-sky-700"
                            >
                                ОК
                            </button>
                        </div>
                    </div>
                </div>
            ) : null}
        </>
    );
}
