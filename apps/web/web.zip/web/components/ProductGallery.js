"use client";

import { useMemo, useState } from "react";

export default function ProductGallery({ images = [], name }) {
    const sorted = useMemo(() => {
        const arr = Array.isArray(images) ? images.slice() : [];
        arr.sort((a, b) => Number(a?.sortOrder || 0) - Number(b?.sortOrder || 0));
        return arr.filter((x) => x?.url);
    }, [images]);

    const [active, setActive] = useState(0);

    const mainUrl = sorted[active]?.url || sorted[0]?.url || "";

    return (
        <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
            <div className="aspect-[4/3] bg-slate-50">
                {mainUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={mainUrl} alt={name} className="h-full w-full object-cover" />
                ) : null}
            </div>

            {sorted.length > 1 ? (
                <div className="border-t border-slate-200 bg-white p-3">
                    <div className="flex gap-2 overflow-x-auto">
                        {sorted.map((img, idx) => (
                            <button
                                key={img.id || img.url}
                                type="button"
                                onClick={() => setActive(idx)}
                                className={[
                                    "relative h-16 w-24 flex-none overflow-hidden rounded-lg border bg-slate-50 shadow-sm transition",
                                    idx === active
                                        ? "border-sky-500 ring-4 ring-slate-100"
                                        : "border-slate-200 hover:border-slate-300",
                                ].join(" ")}
                                aria-label={`Снимка ${idx + 1}`}
                            >
                                {/* eslint-disable-next-line @next/next/no-img-element */}
                                <img src={img.url} alt={name} className="h-full w-full object-cover" />
                            </button>
                        ))}
                    </div>
                </div>
            ) : null}
        </div>
    );
}
